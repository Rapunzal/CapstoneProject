export class Product{
   
    id!: number;
    name!: string;
    price!: number;
    url!: string;
    category!: string;
    quantity!: number;
}